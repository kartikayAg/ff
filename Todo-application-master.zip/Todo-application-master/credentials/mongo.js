module.exports = {
    remoteConnString: '<PASTE YOUR REMOTE CONN STRING>',
    localConnString: 'mongodb://localhost:27017/todo'
}